import React from 'react';
import './FloatingFooter.css';

function FloatingFooter() {
  return (
    <div className="floating-footer">
      Created By Tarek Mahran
    </div>
  );
}

export default FloatingFooter;
